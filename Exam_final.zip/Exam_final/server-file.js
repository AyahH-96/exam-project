const express = require ('express');
const app = express();
const fs = require('fs');

app.set('view engine', 'ejs');
app.set('views', __dirname + '/views');
app.use(express.static(__dirname + '/views'))

app.get('/', function(request, response) {
    let fullData = fs.readFileSync('HarryPotterDataFullData.json', 'utf8')
    let hpData = JSON.parse(fullData);
    let scriptJson = fs.readFileSync('HarryPotterDataScriptOnly.json', 'utf8');
    let scriptData = JSON.parse(scriptJson)
    let shortCharacterJson = fs.readFileSync("HarryPotterDataCharactersOnly.json", "utf8");
    let shortCharacterData = JSON.parse(shortCharacterJson)
    let characterJson = fs.readFileSync("HarryPotterDataCharactersFullForReal.json", "utf8");
    let characterData = JSON.parse(characterJson)
    response.render('index', {
        data: hpData,
        script: scriptData,
        shortCharacter: shortCharacterData,
        characters: characterData
    })
});

app.listen(8080, function() {
    console.log('server listening on port 8080')
})