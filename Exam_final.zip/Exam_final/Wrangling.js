const fs = require("fs");
const papa = require("papaparse");
const movie = fs.readFileSync('hp1.csv', 'utf-8'); //exchanged dataset for each movie
const characterData = fs.readFileSync('shortversioncharacters.csv', 'utf-8');
const parsedScript = papa.parse(movie).data;
const parsedCharacters = papa.parse(characterData).data;
let Sentiment = require('sentiment');


//FILTERING OUT UNDEFINED IN BOTH DATASETS
let characters = parsedCharacters.filter(element => {
    if(element[0] !== undefined && element[1] !== undefined && element[2] !== undefined && element[6] !== undefined
        && element[14] !== undefined){
        return element;
    }
})

let script = parsedScript.filter(element => {
    if(element[1] !== undefined && element[3] !== undefined){
        return element;
    }
})

//CLEANING SCRIPTS AND DOING SENTIMENT ANALYSIS
let cleanData = [];
let joinedData = [];
script[0].push("classification")



script.forEach(element => {
    element[0] = element[0].replace(/^Harry Potter and the Gobelt of Fire$/g, "Harry Potter and the Goblet of Fire");
    let sentiment = new Sentiment();
    let result = sentiment.analyze(element[3]);
    let newArray = [element[0], element[1], element[2], element[3], result];

    if(result.comparative <-0.5) {
        newArray.push("Negative")
    } else if(result.comparative >=-0.5 && result.comparative <=0.5) {
        newArray.push("Neutral")
    } else if(result.comparative >0.5) {
        newArray.push("Positive")
    }
    cleanData.push(newArray) //didnt need squarebrackets
})


//PUSHING ONLY THE ELEMENTS I WANT INTO A NEW ARRAY. USING FUNCTION BECAUSE IT AUTOMIZES THE CLEANING OF THE DIFFERENT SCRIPTS

function sortingHat(array){
    array.forEach(element => {
        if (element[0] === "Harry Potter and the Philosopher's Stone") {
            joinedData.push({"title": "1. " + element[0], "scene": element[1], "character_name": element[2], "dialogue": element[3],
                "score": element[4], "classification": element[5]});
            fs.appendFileSync('HarryPotterDataScriptOnly.json', JSON.stringify({"title": "1. " + element[0], "scene": element[1], "character_name": element[2], "dialogue": element[3],
                "score": element[4], "classification": element[5]}) + ',' + '\n');
        } else if (element[0] === "Harry Potter and the Chamber of Secrets") {
            joinedData.push({"title": "2. " + element[0], "scene": element[1], "character_name": element[2], "dialogue": element[3],
                "score": element[4], "classification": element[5]});
            fs.appendFileSync('HarryPotterDataScriptOnly.json', JSON.stringify({"title": "2. " + element[0], "scene": element[1], "character_name": element[2], "dialogue": element[3],
                "score": element[4], "classification": element[5]}) + ',' + '\n');
        } else if (element[0] === "Harry Potter and the Prisoner of Azkaban") {
            joinedData.push({"title": "3. " +  element[0], "scene": element[1], "character_name": element[2], "dialogue": element[3],
                "score": element[4], "classification": element[5]});
            fs.appendFileSync('HarryPotterDataScriptOnly.json', JSON.stringify({"title": "3. " + element[0], "scene": element[1], "character_name": element[2], "dialogue": element[3],
                "score": element[4], "classification": element[5]}) + ',' + '\n');
        } else if (element[0] === "Harry Potter and the Goblet of Fire") {
            joinedData.push({"title": "4. " + element[0], "scene": element[1], "character_name": element[2], "dialogue": element[3],
                "score": element[4], "classification": element[5]});
            fs.appendFileSync('HarryPotterDataScriptOnly.json', JSON.stringify({"title": "4. " + element[0], "scene": element[1], "character_name": element[2], "dialogue": element[3],
                "score": element[4], "classification": element[5]}) + ',' + '\n');
        } else if (element[0] === "Harry Potter and the Order of the Phoenix") {
            joinedData.push({"title": "5. " + element[0], "scene": element[1], "character_name": element[2], "dialogue": element[3],
                "score": element[4], "classification": element[5]});
            fs.appendFileSync('HarryPotterDataScriptOnly.json', JSON.stringify({"title": "5. " + element[0], "scene": element[1], "character_name": element[2], "dialogue": element[3],
                "score": element[4], "classification": element[5]}) + ',' + '\n');
        } else if (element[0] === "Harry Potter and the Half-Blood Prince") {
            joinedData.push({"title": "6. " + element[0], "scene": element[1], "character_name": element[2], "dialogue": element[3],
                "score": element[4], "classification": element[5]});
            fs.appendFileSync('HarryPotterDataScriptOnly.json', JSON.stringify({"title": "6. " + element[0], "scene": element[1], "character_name": element[2], "dialogue": element[3],
                "score": element[4], "classification": element[5]}) + ',' + '\n');
        } else if (element[0] === "Harry Potter and the Deathly Hallows Part 1") {
            joinedData.push({"title": "7. " + element[0], "scene": element[1], "character_name": element[2], "dialogue": element[3],
                "score": element[4], "classification": element[5]});
            fs.appendFileSync('HarryPotterDataScriptOnly.json', JSON.stringify({"title": "7. " + element[0], "scene": element[1], "character_name": element[2], "dialogue": element[3],
                "score": element[4], "classification": element[5]}) + ',' + '\n');
        } else if (element[0] === "Harry Potter and the Deathly Hallows Part 2") {
            joinedData.push({"title": "8. " + element[0], "scene": element[1], "character_name": element[2], "dialogue": element[3],
                "score": element[4], "classification": element[5]});
            fs.appendFileSync('HarryPotterDataScriptOnly.json', JSON.stringify({"title": "8. " + element[0], "scene": element[1], "character_name": element[2], "dialogue": element[3],
                "score": element[4], "classification": element[5]}) + ',' + '\n');
        }
    })
};

sortingHat(cleanData)

//CLEANING DATASET WITH CHARACTER INFORMATION
characters.forEach(element => {
    element[0] = element[0].replace(/\n/g, "");
    element[0] = element[0].replace(/^Lord Voldemort$/g, "Voldemort");
    element[3] = element[3].replace(/^$/g, "unknown");
    element[6] = element[6].replace(/^$/g, "unknown");
    element[10] = element[10].replace(/^$/g, "unknown");
    /*fs.appendFileSync('HarryPotterDataCharactersOnly.json', JSON.stringify({"character_name": element[0],
       "species": element[1], "gender": element[2], "house": element[3], "ancestry": element[6],
       "wand": element[9], "alive": element[14]}) + ',' + '\n');*/
    for(let data in joinedData) { //COMBINING SCRIPT - AND CHARACTER-DATASETS
        if(element[0] === joinedData[data].character_name) {
            fs.appendFileSync('HarryPotterDataFullData.json', JSON.stringify({"title": joinedData[data].title, "scene": joinedData[data].scene,
                "character_name": joinedData[data].character_name, "dialogue": joinedData[data].dialogue, "sentiment": joinedData[data].score,
                "classification": joinedData[data].classification, "species": element[1], "gender": element[2], "house": element[3], "ancestry": element[6],
                "wand": element[9], "alive": element[14]}) + ',' + '\n');
        }  //I had to remove the append that made a set with only character data as it affected the full dataset. Lots of the script lines doubled.
    }
})
